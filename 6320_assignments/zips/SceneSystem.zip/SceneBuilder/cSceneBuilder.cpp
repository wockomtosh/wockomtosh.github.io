#include "cSceneBuilder.h"

#include <fstream>

#include <Engine/Asserts/Asserts.h>
#include <Engine/Math/cQuaternion.h>
#include <Engine/Math/sVector.h>
#include <Engine/Platform/Platform.h>
#include <Engine/ScopeGuard/cScopeGuard.h>
#include <Engine/Results/Results.h>
#include <External/Lua/Includes.h>
#include <Tools/AssetBuildLibrary/Functions.h>

namespace
{
	// This is where I read in the additional data
	eae6320::cResult ReadSceneObjectAdditionalDataFromLuaState(lua_State* luaState, int currentIndex, std::vector<std::vector<std::pair<std::string, std::string>>>& o_sceneObjectAdditionalData, 
		std::string& errorMessage)
	{
		auto result = eae6320::Results::Success;

		// Get the additional data table
		const char* dataKey = "additionalData";
		lua_pushstring(luaState, dataKey);
		lua_gettable(luaState, -2);

		if (!lua_istable(luaState, -1))
		{
			result = eae6320::Results::InvalidFile;
			errorMessage = "Additonal data is not a table";
			lua_pop(luaState, 1);
			return result;
		}
		else
		{
			// Read the table as an array of pairs
			int arrayLength = static_cast<int>(luaL_len(luaState, -1));
			std::vector<std::pair<std::string, std::string>> additionalData(arrayLength);
			for (int i = 1; i <= arrayLength; i++)
			{
				lua_pushinteger(luaState, i);
				lua_gettable(luaState, -2);

				if (!lua_istable(luaState, -1))
				{
					result = eae6320::Results::InvalidFile;
					errorMessage = "Additional data entry is not a table";
					lua_pop(luaState, 1);
					return result;
				}
				else
				{
					// Store each value in the pair as a std::pair in my std::vector
					std::pair<std::string, std::string> dataPair;

					lua_pushinteger(luaState, 1);
					lua_gettable(luaState, -2);

					if (!lua_isstring(luaState, -1))
					{
						result = eae6320::Results::InvalidFile;
						errorMessage = "Additional data key is not a string";
						lua_pop(luaState, 1);
						return result;
					}
					else
					{
						dataPair.first = lua_tostring(luaState, -1);
						lua_pop(luaState, 1);
					}

					lua_pushinteger(luaState, 2);
					lua_gettable(luaState, -2);

					if (!lua_isstring(luaState, -1))
					{
						result = eae6320::Results::InvalidFile;
						errorMessage = "Additional data value is not a string";
						lua_pop(luaState, 1);
						return result;
					}
					else
					{
						dataPair.second = lua_tostring(luaState, -1);
						lua_pop(luaState, 1);
					}
					additionalData[i - 1] = dataPair;
					lua_pop(luaState, 1);
				}
			}
			// Put my std::vector at position currentIndex in o_sceneObjectAdditionalData (space has already been reserved)
			o_sceneObjectAdditionalData[currentIndex] = additionalData;
			lua_pop(luaState, 1);
		}

		return result;
	}

	// This is where I get type, position, orientation, and persistence
	eae6320::cResult ReadSceneObjectBaseDataFromLuaState(lua_State* luaState, int currentIndex, int& o_numSceneObjects, uint16_t*& o_sceneObjectTypes, eae6320::Math::sVector*& o_sceneObjectPositions,
		eae6320::Math::cQuaternion*& o_sceneObjectOrientations, bool*& o_areSceneObjectsPersistentBetweenScenes, std::string& errorMessage)
	{
		auto result = eae6320::Results::Success;

		// We want to read and store type, position, orientation, and persistentBetweenScenes

		const char* typeKey = "type";
		lua_pushstring(luaState, typeKey);
		lua_gettable(luaState, -2);

		if (!lua_isnumber(luaState, -1))
		{
			result = eae6320::Results::InvalidFile;
			errorMessage = "Type is not a number";
			lua_pop(luaState, 1);
			return result;
		}
		else
		{
			o_sceneObjectTypes[currentIndex] = static_cast<uint16_t>(lua_tonumber(luaState, -1));
			lua_pop(luaState, 1);
		}

		const char* positionKey = "position";
		lua_pushstring(luaState, positionKey);
		lua_gettable(luaState, -2);

		if (!lua_istable(luaState, -1))
		{
			// Position is optional
			eae6320::Math::sVector position(0,0,0);
			o_sceneObjectPositions[currentIndex] = position;
			lua_pop(luaState, 1);
		}
		else
		{
			const auto arrayLength = luaL_len(luaState, -1);
			if (arrayLength == 3)
			{
				eae6320::Math::sVector position;

				lua_pushinteger(luaState, 1);
				lua_gettable(luaState, -2);
				if (!lua_isnumber(luaState, -1))
				{
					result = eae6320::Results::InvalidFile;
					errorMessage = "X value is not a number";
					lua_pop(luaState, 1);
					return result;
				}
				else
				{
					position.x = static_cast<float>(lua_tonumber(luaState, -1));
					lua_pop(luaState, 1);
				}

				lua_pushinteger(luaState, 2);
				lua_gettable(luaState, -2);
				if (!lua_isnumber(luaState, -1))
				{
					result = eae6320::Results::InvalidFile;
					errorMessage = "Y value is not a number";
					lua_pop(luaState, 1);
					return result;
				}
				else
				{
					position.y = static_cast<float>(lua_tonumber(luaState, -1));
					lua_pop(luaState, 1);
				}

				lua_pushinteger(luaState, 3);
				lua_gettable(luaState, -2);
				if (!lua_isnumber(luaState, -1))
				{
					result = eae6320::Results::InvalidFile;
					errorMessage = "Z value is not a number";
					lua_pop(luaState, 1);
					return result;
				}
				else
				{
					position.z = static_cast<float>(lua_tonumber(luaState, -1));
					lua_pop(luaState, 1);
				}

				o_sceneObjectPositions[currentIndex] = position;
			}
			else
			{
				result = eae6320::Results::InvalidFile;
				errorMessage = "The position table is invalid";
				return result;
			}
			lua_pop(luaState, 1);
		}

		const char* orientationKey = "orientation";
		lua_pushstring(luaState, orientationKey);
		lua_gettable(luaState, -2);

		if (!lua_istable(luaState, -1))
		{
			// Orientation is optional
			eae6320::Math::cQuaternion orientation;
			o_sceneObjectOrientations[currentIndex] = orientation;
			lua_pop(luaState, 1);
		}
		else
		{
			float angleInRadians = 0;
			eae6320::Math::sVector axisOfRotation;

			const char* angleKey = "angleInRadians";
			lua_pushstring(luaState, angleKey);
			lua_gettable(luaState, -2);

			if (!lua_isnumber(luaState, -1))
			{
				result = eae6320::Results::InvalidFile;
				errorMessage = "Angle is not a number";
				lua_pop(luaState, 1);
				return result;
			}
			else
			{
				angleInRadians = static_cast<uint16_t>(lua_tonumber(luaState, -1));
				lua_pop(luaState, 1);
			}

			const char* axisKey = "axisOfRotation";
			lua_pushstring(luaState, axisKey);
			lua_gettable(luaState, -2);

			eae6320::Math::sVector axis;

			if (!lua_istable(luaState, -1))
			{
				result = eae6320::Results::InvalidFile;
				errorMessage = "Axis of Rotation is not a table";
				lua_pop(luaState, 1);
				return result;
			}
			else
			{
				const auto arrayLength = luaL_len(luaState, -1);
				if (arrayLength == 3)
				{
					lua_pushinteger(luaState, 1);
					lua_gettable(luaState, -2);
					if (!lua_isnumber(luaState, -1))
					{
						result = eae6320::Results::InvalidFile;
						errorMessage = "X value is not a number";
						lua_pop(luaState, 1);
						return result;
					}
					else
					{
						axis.x = static_cast<float>(lua_tonumber(luaState, -1));
						lua_pop(luaState, 1);
					}

					lua_pushinteger(luaState, 2);
					lua_gettable(luaState, -2);
					if (!lua_isnumber(luaState, -1))
					{
						result = eae6320::Results::InvalidFile;
						errorMessage = "Y value is not a number";
						lua_pop(luaState, 1);
						return result;
					}
					else
					{
						axis.y = static_cast<float>(lua_tonumber(luaState, -1));
						lua_pop(luaState, 1);
					}

					lua_pushinteger(luaState, 3);
					lua_gettable(luaState, -2);
					if (!lua_isnumber(luaState, -1))
					{
						result = eae6320::Results::InvalidFile;
						errorMessage = "Z value is not a number";
						lua_pop(luaState, 1);
						return result;
					}
					else
					{
						axis.z = static_cast<float>(lua_tonumber(luaState, -1));
						lua_pop(luaState, 1);
					}
					lua_pop(luaState, 1);
				}
				else
				{
					result = eae6320::Results::InvalidFile;
					errorMessage = "The axis of rotation table is invalid";
					lua_pop(luaState, 1);
					return result;
				}
			}

			eae6320::Math::cQuaternion rotation(angleInRadians, axis);
			o_sceneObjectOrientations[currentIndex] = rotation;
			lua_pop(luaState, 1);
		}

		const char* persistentKey = "persistentBetweenScenes";
		lua_pushstring(luaState, persistentKey);
		lua_gettable(luaState, -2);

		if (!lua_isboolean(luaState, -1))
		{
			// Persistence is optional
			o_areSceneObjectsPersistentBetweenScenes[currentIndex] = false;
			lua_pop(luaState, 1);
		}
		else
		{
			o_areSceneObjectsPersistentBetweenScenes[currentIndex] = lua_toboolean(luaState, -1);
			lua_pop(luaState, 1);
		}

		return result;
	}

	eae6320::cResult ReadSceneObjectDataFromLuaState(lua_State* luaState, int currentIndex, int& o_numSceneObjects, uint16_t*& o_sceneObjectTypes, eae6320::Math::sVector*& o_sceneObjectPositions,
		eae6320::Math::cQuaternion*& o_sceneObjectOrientations, bool*& o_areSceneObjectsPersistentBetweenScenes,
		std::vector<std::vector<std::pair<std::string, std::string>>>& o_sceneObjectAdditionalData, std::string& errorMessage)
	{
		auto result = eae6320::Results::Success;

		// Process the base data
		if (!(result = ReadSceneObjectBaseDataFromLuaState(luaState, currentIndex, o_numSceneObjects, o_sceneObjectTypes, o_sceneObjectPositions, o_sceneObjectOrientations,
			o_areSceneObjectsPersistentBetweenScenes, errorMessage)))
		{
			return result;
		}

		// Process the additional data
		if (!(result = ReadSceneObjectAdditionalDataFromLuaState(luaState, currentIndex, o_sceneObjectAdditionalData, errorMessage)))
		{
			return result;
		}

		return result;
	}

	//Load in all scene objects
	eae6320::cResult ReadSceneDataFromLuaState(lua_State* luaState, int& o_numSceneObjects, uint16_t*& o_sceneObjectTypes, eae6320::Math::sVector*& o_sceneObjectPositions,
		eae6320::Math::cQuaternion*& o_sceneObjectOrientations, bool*& o_areSceneObjectsPersistentBetweenScenes,
		std::vector<std::vector<std::pair<std::string, std::string>>>& o_sceneObjectAdditionalData, std::string& errorMessage)
	{
		auto result = eae6320::Results::Success;

		// We already checked to make sure we have a table, so we just jump into it.
		o_numSceneObjects = static_cast<int>(luaL_len(luaState, -1));
		if (o_numSceneObjects > 0)
		{
			// Allocate memory for all of our lists where we store the requisite data, except for our vector since that handles itself
			o_sceneObjectTypes = new uint16_t[o_numSceneObjects];
			o_sceneObjectPositions = new eae6320::Math::sVector[o_numSceneObjects];
			o_sceneObjectOrientations = new eae6320::Math::cQuaternion[o_numSceneObjects];
			o_areSceneObjectsPersistentBetweenScenes = new bool[o_numSceneObjects];
			o_sceneObjectAdditionalData = std::vector<std::vector<std::pair<std::string, std::string>>>(o_numSceneObjects);

			for (int i = 1; i <= o_numSceneObjects; i++)
			{
				// Get a particular object in the list
				lua_pushinteger(luaState, i);
				lua_gettable(luaState, -2);

				if (!lua_istable(luaState, -1))
				{
					result = eae6320::Results::InvalidFile;
					errorMessage = "Scene object is not a table";
					lua_pop(luaState, 1);
					return result;
				}
				else
				{
					// Process the scene object, then pop
					if (!(result = ReadSceneObjectDataFromLuaState(luaState, i - 1, o_numSceneObjects, o_sceneObjectTypes, o_sceneObjectPositions, o_sceneObjectOrientations,
						o_areSceneObjectsPersistentBetweenScenes, o_sceneObjectAdditionalData, errorMessage)))
					{
						result = eae6320::Results::InvalidFile;
						lua_pop(luaState, 1);
						return result;
					}
					else
					{
						lua_pop(luaState, 1);
					}
				}
			}
		}

		return result;
	}

	eae6320::cResult LoadSceneFromLuaFile(const char* const i_path, int& o_numSceneObjects, uint16_t*& o_sceneObjectTypes, eae6320::Math::sVector*& o_sceneObjectPositions,
		eae6320::Math::cQuaternion*& o_sceneObjectOrientations, bool*& o_areSceneObjectsPersistentBetweenScenes,
		std::vector<std::vector<std::pair<std::string, std::string>>>& o_sceneObjectAdditionalData, std::string& errorMessage)
	{
		auto result = eae6320::Results::Success;

		lua_State* luaState = nullptr;
		eae6320::cScopeGuard scopeGuard_onExit([&luaState]
			{
				if (luaState)
				{
					// Check to make sure that the stack is empty
					EAE6320_ASSERT(lua_gettop(luaState) == 0);

					lua_close(luaState);
					luaState = nullptr;
				}
			});

		luaState = luaL_newstate();
		if (!luaState)
		{
			result = eae6320::Results::OutOfMemory;
			errorMessage = "Failed to create lua state";
			return result;
		}

		// Load in the actual scene file
		const auto stackTopBeforeLoading = lua_gettop(luaState);
		const auto luaResult = luaL_dofile(luaState, i_path);
		if (luaResult == LUA_OK)
		{
			// Make sure it's just one return value
			const auto returnedValueCount = lua_gettop(luaState) - stackTopBeforeLoading;
			if (returnedValueCount == 1)
			{
				// Make sure it's a table
				if (!lua_istable(luaState, -1))
				{
					result = eae6320::Results::InvalidFile;
					errorMessage = "Scene files must return a table, this scene does not return a table.";
					// Pop that value to clear it out
					lua_pop(luaState, 1);
					return result;
				}
			}
			else
			{
				result = eae6320::Results::InvalidFile;
				errorMessage = "Scene files must return a single table, this scene returns multiple values.";
				// Pop the values to clear the stack
				lua_pop(luaState, returnedValueCount);
				return result;
			}
		}
		else
		{
			result = eae6320::Results::Failure;
			errorMessage = lua_tostring(luaState, -1);
			// Don't forget to pop the error
			lua_pop(luaState, 1);
			return result;
		}

		// The file has been loaded successfully, we need to process it then pop it to clean up
		result = ReadSceneDataFromLuaState(luaState, o_numSceneObjects, o_sceneObjectTypes, o_sceneObjectPositions, o_sceneObjectOrientations,
			o_areSceneObjectsPersistentBetweenScenes, o_sceneObjectAdditionalData, errorMessage);

		lua_pop(luaState, 1);

		return result;
	}
}

eae6320::cResult eae6320::Assets::cSceneBuilder::Build(const std::vector<std::string>& i_arguments)
{
	cResult result = eae6320::Results::Success;

	std::string errorMessage = "";

	// DATA NEEDED for each object:
	// Type - Required
	// Position - Defaults to 0,0,0
	// Orientation - Defaults to 0, 0, 0, 0
	// PersistentBetweenScenes - Defaults to false
	// Num Additional Data - Defaults to 0
	// Additional Data - Defaults to empty

	// While we still have objects: keep loading objects
	// We can allocate memory for objects based on the length of the top level Lua array.
	// We can store them in arrays of uint16_t, sVector, cQuaternion

	int numSceneObjects;
	uint16_t* sceneObjectTypes;
	Math::sVector* sceneObjectPositions;
	Math::cQuaternion* sceneObjectOrientations;
	bool* areSceneObjectsPersistentBetweenScenes;
	std::vector<std::vector<std::pair<std::string, std::string>>> sceneObjectAdditionalData;


	if (!(result = LoadSceneFromLuaFile(m_path_source, numSceneObjects, sceneObjectTypes, sceneObjectPositions, 
		sceneObjectOrientations, areSceneObjectsPersistentBetweenScenes, sceneObjectAdditionalData, errorMessage))
		|| errorMessage != "")
	{
		OutputErrorMessageWithFileInfo(m_path_source, errorMessage.c_str());
		return result;
	}

	if (numSceneObjects == 0 || sceneObjectTypes == nullptr || sceneObjectPositions == nullptr || sceneObjectOrientations == nullptr 
		|| areSceneObjectsPersistentBetweenScenes == nullptr || sceneObjectAdditionalData.size() == 0)
	{
		result = Results::Failure;
		OutputErrorMessageWithFileInfo(m_path_source, "Invalid scene data");
		return result;
	}

	// My ordering is type, position, orientation, persistentBetweenScenes, then additional data
	std::ofstream binaryFile(m_path_target, std::ofstream::binary);

	// Put the number of objects at the very beginning
	size_t numObjectsSize = sizeof(numSceneObjects);
	char* numObjectsBuffer = new char[numObjectsSize];
	memcpy(numObjectsBuffer, &numSceneObjects, numObjectsSize);

	binaryFile.write(numObjectsBuffer, numObjectsSize);
	delete[] numObjectsBuffer;


	size_t typeSize = sizeof(uint16_t);
	size_t positionSize = sizeof(eae6320::Math::sVector);
	size_t orientationSize = sizeof(eae6320::Math::cQuaternion);
	size_t persistentSize = sizeof(bool);
	// Additional data will have to be measured per object
	// Getting a buffer size ahead of time for the whole object is tricky because we can't tell how long it is without checking all additional data

	

	for (int i = 0; i < numSceneObjects; i++)
	{
		size_t objectBaseDataBufferSize = typeSize + positionSize + orientationSize + persistentSize;

		char* objectBaseDataFileBuffer = new char[objectBaseDataBufferSize];

		memcpy(objectBaseDataFileBuffer, &sceneObjectTypes[i], typeSize);
		memcpy(&objectBaseDataFileBuffer[typeSize], &sceneObjectPositions[i], positionSize);
		memcpy(&objectBaseDataFileBuffer[typeSize + positionSize], &sceneObjectOrientations[i], orientationSize);
		memcpy(&objectBaseDataFileBuffer[typeSize + positionSize + orientationSize], &areSceneObjectsPersistentBetweenScenes[i], persistentSize);

		binaryFile.write(objectBaseDataFileBuffer, objectBaseDataBufferSize);
		delete[] objectBaseDataFileBuffer;

		// To write additional data we need to write each pair of strings. It will be a length followed by the actual string data
		// I'm going to use uint16_ts for length to save some space
		// I also need a number of pairs at the very beginning so I know how many to read
		uint16_t numPairs = static_cast<uint16_t>(sceneObjectAdditionalData[i].size());
		binaryFile.write((char*)&numPairs, sizeof(uint16_t));
		for (int j = 0; j < numPairs; j++)
		{
			std::pair<std::string, std::string> curPair = sceneObjectAdditionalData[i][j];

			// I'm adding 1 to the size so that we include the null terminator when we write. That'll be safer when I'm reading/storing it later.
			uint16_t firstLength = static_cast<uint16_t>(curPair.first.size()) + 1;
			uint16_t secondLength = static_cast<uint16_t>(curPair.second.size()) + 1;
			size_t lengthSize = sizeof(uint16_t);

			size_t pairBufferSize = firstLength + secondLength + (lengthSize * 2);
			char* pairBuffer = new char[pairBufferSize];

			if (pairBufferSize >= 2)
			{
				memcpy(pairBuffer, &firstLength, lengthSize);
				memcpy(&pairBuffer[lengthSize], curPair.first.c_str(), firstLength);
				memcpy(&pairBuffer[lengthSize + firstLength], &secondLength, lengthSize);
				memcpy(&pairBuffer[lengthSize + firstLength + lengthSize], curPair.second.c_str(), secondLength);
			}

			binaryFile.write(pairBuffer, pairBufferSize);
			delete[] pairBuffer;
		}
	}
	
	binaryFile.close();

	if (sceneObjectTypes) {
		delete[] sceneObjectTypes;
	}
	if (sceneObjectPositions) {
		delete[] sceneObjectPositions;
	}
	if (sceneObjectOrientations) {
		delete[] sceneObjectOrientations;
	}
	if (areSceneObjectsPersistentBetweenScenes) {
		delete[] areSceneObjectsPersistentBetweenScenes;
	}

	return result;
}
