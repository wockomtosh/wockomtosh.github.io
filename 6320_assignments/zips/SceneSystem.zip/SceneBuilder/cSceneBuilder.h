/*
	This class builds scenes
*/

#ifndef EAE6320_CSCENEBUILDER_H
#define EAE6320_CSCENEBUILDER_H

// Includes
//=========

#include <Tools/AssetBuildLibrary/iBuilder.h>

// Class Declaration
//==================

namespace eae6320
{
	namespace Assets
	{
		class cSceneBuilder final : public iBuilder
		{
			// Inherited Implementation
			//=========================

		private:

			// Build
			//------

			cResult Build(const std::vector<std::string>& i_arguments) final;
		};
	}
}

#endif	// EAE6320_CSCENEBUILDER_H
