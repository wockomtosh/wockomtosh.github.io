#include "Scene.h"

#include <Engine/Asserts/Asserts.h>
#include <Engine/Platform/Platform.h>

namespace
{
    const char* SCENE_FOLDER_PATH = "data/scenes/";
    const int SCENE_PATH_LENGTH = 12; //This doesn't count the null terminator since we want to add this to a file name

    // Users need to register their object load functions with the scene
    // Normally I'd avoid std::string but I ran into some issues with using char*s as keys
    std::unordered_map <uint16_t, std::function<eae6320::cResult(eae6320::Scene::cSceneObject*& o_sceneObject, std::unordered_map<std::string, std::string> additionalData)>> sceneObjectLoadFunctions;

    // If we didn't care about memory and STL and stuff using maps for these might be nice. But it might not help in a lot of situations. It's likely a tradeoff of memory for speed. 
    // I could see the scenes being stored in a map by ID being useful. It would make getting objects and scenes by ID much faster (probably).
    // But getting all scene objects of a particular type would be just as slow since we'd still need to iterate through everything, and my guess is that that's the most useful
    // function for finding objects. 
    
    // This is a preallocated array of pointers to scene objects. We need to be careful with memory management here. 
    // It's an array of pointers because other objects derive from cSceneObject.
    // We keep persistent objects separately because if their scene is unloaded they need a place to stay.
    eae6320::Scene::cSceneObject** persistentSceneObjects = nullptr;
    int numPersistentSceneObjects = 0;
    int maxPersistentSceneObjects = 0;

    // Having objects split up by scene makes it more efficient/easier to unload a particular scene during level streaming
    eae6320::Scene::sSceneData* loadedScenes = nullptr;
    int numLoadedScenes = 0;
    int maxLoadedScenes = 0;
}

namespace
{
    eae6320::cResult LoadDerivedSceneObject(uint16_t i_objectType, eae6320::Scene::cSceneObject*& o_sceneObject, std::unordered_map<std::string, std::string> additionalData)
    {
        eae6320::cResult result = eae6320::Results::Success;

        auto objectLoadFunction = sceneObjectLoadFunctions.at(i_objectType);
        if (!(result = objectLoadFunction(o_sceneObject, additionalData)))
        {
            EAE6320_ASSERTF(false, "Object failed to load");
            return result;
        }
        
        // If the load function succeeded this should never be a nullptr, but just in case
        if (o_sceneObject)
        {
            o_sceneObject->SetObjectType(i_objectType);
        }
        else 
        {
            EAE6320_ASSERTF(false, "Load succeeded but object is nullptr");
            return eae6320::Results::Failure;
        }
        return result;
    }

    //We take in the list of scene objects to fill along with the list of persistent objects to add to that if we need to.
    eae6320::cResult LoadSceneFromBinary(const char* const i_path, int& o_numSceneObjects, eae6320::Scene::cSceneObject**& o_sceneObjects, int& o_numPersistentSceneObjects, eae6320::Scene::cSceneObject**& o_persistentSceneObjects)
    {
        eae6320::cResult result = eae6320::Results::Success;

        std::string* errorMessage = nullptr;
        eae6320::Platform::sDataFromFile sceneData;

        if (!(result = eae6320::Platform::LoadBinaryFile(i_path, sceneData, errorMessage)))
        {
            if (errorMessage)
            {
                EAE6320_ASSERTF(false, errorMessage->c_str());
                delete errorMessage;
            }
            sceneData.Free();
            return result;
        }

        uintptr_t currentDataOffset = reinterpret_cast<uintptr_t>(sceneData.data);

        int totalSceneObjects = *reinterpret_cast<int*>(currentDataOffset);
        currentDataOffset += sizeof(totalSceneObjects);

        o_numPersistentSceneObjects = 0;

        eae6320::Scene::cSceneObject** allSceneObjects = new eae6320::Scene::cSceneObject*[totalSceneObjects];

        for (int i = 0; i < totalSceneObjects; i++)
        {
            // The order for objects is type, position, orientation, persistentBetweenScenes, then additionalData
            uint16_t type = *reinterpret_cast<uint16_t*>(currentDataOffset);
            currentDataOffset += sizeof(type);

            eae6320::Math::sVector position = *reinterpret_cast<eae6320::Math::sVector*>(currentDataOffset);
            currentDataOffset += sizeof(position);

            eae6320::Math::cQuaternion orientation = *reinterpret_cast<eae6320::Math::cQuaternion*>(currentDataOffset);
            currentDataOffset += sizeof(orientation);

            bool persistentBetweenScenes = *reinterpret_cast<bool*>(currentDataOffset);
            currentDataOffset += sizeof(persistentBetweenScenes);

            uint16_t numAdditionalDataPairs = *reinterpret_cast<uint16_t*>(currentDataOffset);
            currentDataOffset += sizeof(numAdditionalDataPairs);

            std::unordered_map<std::string, std::string> additionalData;

            for (int j = 0; j < numAdditionalDataPairs; j++)
            {
                size_t lengthSize = sizeof(uint16_t);

                uint16_t firstLength = *reinterpret_cast<uint16_t*>(currentDataOffset);
                currentDataOffset += lengthSize;

                char* key = new char[firstLength];
                memcpy(key, reinterpret_cast<char*>(currentDataOffset), firstLength);
                currentDataOffset += firstLength;

                uint16_t secondLength = *reinterpret_cast<uint16_t*>(currentDataOffset);
                currentDataOffset += lengthSize;

                char* value = new char[secondLength];
                memcpy(value, reinterpret_cast<char*>(currentDataOffset), secondLength);
                currentDataOffset += secondLength;
                
                additionalData.insert(std::pair<std::string, std::string>(std::string(key), std::string(value)));
            }

            if (!(result = sceneObjectLoadFunctions[type](allSceneObjects[i], additionalData)))
            {
                EAE6320_ASSERTF(false, "Error: Object failed to load");
                return result;
            }
            else
            {
                allSceneObjects[i]->SetObjectType(type);
                allSceneObjects[i]->SetPersistentBetweenScenes(persistentBetweenScenes);
                allSceneObjects[i]->m_rigidbody.position = position;
                allSceneObjects[i]->m_rigidbody.orientation = orientation;
            }

            if (persistentBetweenScenes)
            {
                o_numPersistentSceneObjects++;
            }
        }

        // Separate out persistent and regular scene objects
        if (o_numPersistentSceneObjects != 0)
        {
            o_numSceneObjects = totalSceneObjects - o_numPersistentSceneObjects;
            o_sceneObjects = new eae6320::Scene::cSceneObject * [o_numSceneObjects];
            o_persistentSceneObjects = new eae6320::Scene::cSceneObject * [o_numPersistentSceneObjects];

            int curSceneObject = 0;
            int curPersistentObject = 0;
            for (int i = 0; i < totalSceneObjects; i++)
            {
                eae6320::Scene::cSceneObject* curObject = allSceneObjects[i];
                if (allSceneObjects[i]->IsPersistentBetweenScenes())
                {
                    o_persistentSceneObjects[curPersistentObject] = allSceneObjects[i];
                    curPersistentObject++; 
                }
                else
                {
                    o_sceneObjects[curSceneObject] = allSceneObjects[i];
                    curSceneObject++;
                }
            }
            delete[] allSceneObjects;
        }
        else
        {
            o_sceneObjects = allSceneObjects;
        }

        // Empty scenes should maybe be valid, but I'm going to still leave this here for now.
        if ((o_numSceneObjects == 0 && o_numPersistentSceneObjects == 0) || (o_sceneObjects == nullptr && o_persistentSceneObjects == nullptr))
        {
            EAE6320_ASSERTF(false, "Invalid data, there are no scene objects.");
            return eae6320::Results::Failure;
        }

        return result;
    }
    
    void MoveSceneData(int fromIndex, int toIndex)
    {
        loadedScenes[toIndex].m_sceneID = loadedScenes[fromIndex].m_sceneID;
        loadedScenes[toIndex].m_numSceneObjects = loadedScenes[fromIndex].m_numSceneObjects;
        loadedScenes[toIndex].m_sceneObjects = loadedScenes[fromIndex].m_sceneObjects;
        //We don't want to unload the "from" scene because we're still using the objects, but we do want to clear the data
        loadedScenes[fromIndex].m_sceneID = 0;
        loadedScenes[fromIndex].m_numSceneObjects = 0;
        loadedScenes[fromIndex].m_sceneObjects = nullptr;
    }
}

eae6320::cResult eae6320::Scene::Initialize(const uint16_t i_maxPersistentObjects, const uint16_t i_maxLoadedScenes)
{
    auto result = eae6320::Results::Success;

    maxPersistentSceneObjects = i_maxPersistentObjects;
    maxLoadedScenes = i_maxLoadedScenes;
    persistentSceneObjects = new cSceneObject*[maxPersistentSceneObjects];
    loadedScenes = new sSceneData[maxLoadedScenes];

    return result;
}

eae6320::cResult eae6320::Scene::Cleanup()
{
    auto result = eae6320::Results::Success;

    // Delete each individual pointer, then delete the array
    for (int i = 0; i < numPersistentSceneObjects; i++)
    {
        if (persistentSceneObjects[i])
        {
            delete persistentSceneObjects[i];
        }
    }
    delete[] persistentSceneObjects;
    persistentSceneObjects = nullptr;
    numPersistentSceneObjects = 0;
    delete[] loadedScenes;
    loadedScenes = nullptr;
    numLoadedScenes = 0;
    sSceneData::nextSceneID = 0;

    return result;
}

void eae6320::Scene::RegisterObjectLoadFunction(const uint16_t i_objectType, std::function<eae6320::cResult(eae6320::Scene::cSceneObject*& o_sceneObject, std::unordered_map<std::string, std::string> additionalData)> i_objectLoadFunction)
{
    sceneObjectLoadFunctions[i_objectType] = i_objectLoadFunction;
}

eae6320::cResult eae6320::Scene::LoadNewScene(const char* i_path, uint16_t& o_sceneID)
{
    auto result = eae6320::Results::Success;

    // Unload all scenes, then load a new scene
    for (int i = 0; i < numLoadedScenes; i++)
    {
        loadedScenes[i].UnloadData();
    }

    numLoadedScenes = 0;

    if (!(result = LoadAdditionalScene(i_path, o_sceneID))) 
    {
        EAE6320_ASSERTF(false, "Error loading scene.");
        return result;
    }

    return result;
}

eae6320::cResult eae6320::Scene::LoadAdditionalScene(const char* i_path, uint16_t& o_sceneID)
{
    auto result = eae6320::Results::Success;

    int numSceneObjects = 0;
    eae6320::Scene::cSceneObject** sceneObjects = nullptr;
    int numAdditionalPersistentSceneObjects = 0;
    eae6320::Scene::cSceneObject** additionalPersistentSceneObjects = nullptr;

    if (!(result = LoadSceneFromBinary(i_path, numSceneObjects, sceneObjects, numAdditionalPersistentSceneObjects, additionalPersistentSceneObjects)))
    {
        return result;
    }

    // If we have 0 scenes we want index 0, 1 scene we want index 1, etc.
    int sceneIndex = numLoadedScenes;
    loadedScenes[sceneIndex].SetupData(numSceneObjects, sceneObjects);

    o_sceneID = loadedScenes[sceneIndex].m_sceneID;

    // If we have too many persistent objects, show an assert and don't add them, but don't fail.
    if (numPersistentSceneObjects + numAdditionalPersistentSceneObjects > maxPersistentSceneObjects)
    {
        EAE6320_ASSERTF(false, "Trying to load more than the maximum number of persistent scene objects");
    }
    else
    {
        // After we've loaded the scene we need to add our persistent objects to the list
        for (int i = 0; i < numAdditionalPersistentSceneObjects; i++)
        {
            persistentSceneObjects[i + numPersistentSceneObjects] = additionalPersistentSceneObjects[i];
        }
        numPersistentSceneObjects += numAdditionalPersistentSceneObjects;
    }

    // Call OnSceneLoaded for all the scene objects in this scene
    for (int i = 0; i < numSceneObjects; i++)
    {
        sceneObjects[i]->OnSceneLoaded();
    }
    for (int i = 0; i < numAdditionalPersistentSceneObjects; i++)
    {
        additionalPersistentSceneObjects[i]->OnSceneLoaded();
    }

    // We need to delete this array, but not the scene objects within the array (since they're now stored elsewhere)
    delete[] additionalPersistentSceneObjects;

    numLoadedScenes++;

    return result;
}

eae6320::cResult eae6320::Scene::UnloadSceneByID(const uint16_t i_sceneID)
{
    auto result = eae6320::Results::Success;

    if (!loadedScenes)
    {
        EAE6320_ASSERTF(false, "Scenes have not been initialized");
        return eae6320::Results::Failure;
    }

    // When we unload a scene data object we want to clear its data and move it to the back of the array
    // First, find the index of the scene
    int sceneIndexToBeUnloaded = -1;
    for (int i = 0; i < numLoadedScenes; i++)
    {
        if (loadedScenes[i].m_sceneID == i_sceneID)
        {
            sceneIndexToBeUnloaded = i;
            break;
        }
    }
    loadedScenes[sceneIndexToBeUnloaded].UnloadData();

    //Move data in the scene on the back of the array to this scene to do a "swap"
    MoveSceneData(numLoadedScenes - 1, sceneIndexToBeUnloaded);
    numLoadedScenes--;

    return result;
}

eae6320::cResult eae6320::Scene::GetSceneObjectByID(cSceneObject*& o_sceneObject, const uint32_t i_objectID, const uint16_t i_sceneID)
{
    for (int i = 0; i < numLoadedScenes; i++) 
    {
        // If we have a valid scene ID (greater than 0) and it's not that ID, skip it
        if (i_sceneID != 0 && i_sceneID != loadedScenes[i].m_sceneID)
        {
            continue;
        }

        for (int j = 0; j < loadedScenes[i].m_numSceneObjects; j++)
        {
            if (loadedScenes[i].m_sceneObjects[j]->GetObjectID() == i_objectID)
            {
                o_sceneObject = loadedScenes[i].m_sceneObjects[j];
                return eae6320::Results::Success;
            }
        }
    }

    return eae6320::Results::Failure;
}

eae6320::cResult eae6320::Scene::GetSceneDataByID(sSceneData& o_sceneData, const uint16_t i_sceneID)
{
    for (int i = 0; i < numLoadedScenes; i++)
    {
        if (loadedScenes[i].m_sceneID == i_sceneID)
        {
            o_sceneData = loadedScenes[i];
            return eae6320::Results::Success;
        }
    }
    return eae6320::Results::Failure;
}

eae6320::cResult eae6320::Scene::GetPersistentSceneObjects(cSceneObject**& o_persistentSceneObjects, int& o_numPersistentSceneobjects)
{
    if (numPersistentSceneObjects == 0)
    {
        return eae6320::Results::Failure;
    }

    o_persistentSceneObjects = persistentSceneObjects;
    o_numPersistentSceneobjects = numPersistentSceneObjects;

    return eae6320::Results::Success;
}

eae6320::cResult eae6320::Scene::GetSceneObjectsByType(cSceneObject**& o_sceneObjects, int& o_numSceneObjectsOfType, const uint16_t i_objectType, const int maxSceneObjectsReturned, const uint16_t i_sceneID)
{
    // This is tricky because we don't know how many there are, but we need to allocate memory for a list of all of them. 
    // My solution is to make the user pass in a maximum and that will be the space allocated. It's not perfect at all, but I can refactor it later if necessary.

    o_sceneObjects = new cSceneObject*[maxSceneObjectsReturned];
    o_numSceneObjectsOfType = 0;

    // Search through scenes first because I'm guessing users are more likely to track persistent objects on their own
    for (int i = 0; i < numLoadedScenes; i++)
    {
        // If we have a valid scene ID (greater than 0) and it's not that ID, skip it
        if (i_sceneID != 0 && i_sceneID != loadedScenes[i].m_sceneID)
        {
            continue;
        }

        for (int j = 0; j < loadedScenes[i].m_numSceneObjects; j++)
        {
            if (loadedScenes[i].m_sceneObjects[j]->GetObjectType() == i_objectType)
            {
                if (o_numSceneObjectsOfType < maxSceneObjectsReturned)
                {
                    o_sceneObjects[o_numSceneObjectsOfType] = loadedScenes[i].m_sceneObjects[j];
                    o_numSceneObjectsOfType++;
                    if (o_numSceneObjectsOfType >= maxSceneObjectsReturned)
                    {
                        return eae6320::Results::Success;
                    }
                }
                else 
                {
                    return eae6320::Results::Success;
                }
            }
        }

        //If we have a valid scene ID and we've finished searching that scene, return. TODO: confirm that this works as expected
        if (i_sceneID != 0)
        {
            return eae6320::Results::Success;
        }
    }

    // Only search through persistent objects if they don't give a valid scene ID
    if (i_sceneID == 0)
    {
        for (int i = 0; i < numPersistentSceneObjects; i++)
        {
            if (persistentSceneObjects[i]->GetObjectType() == i_objectType)
            {
                if (o_numSceneObjectsOfType < maxSceneObjectsReturned)
                {
                    o_sceneObjects[o_numSceneObjectsOfType] = persistentSceneObjects[i];
                    o_numSceneObjectsOfType++;
                    if (o_numSceneObjectsOfType >= maxSceneObjectsReturned)
                    {
                        return eae6320::Results::Success;
                    }
                    else
                    {
                        return eae6320::Results::Success;
                    }
                }
                else
                {
                    return eae6320::Results::Success;
                }
            }
        }
    }

    return eae6320::Results::Success;
}
