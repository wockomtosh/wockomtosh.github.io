#pragma once
#include "cSceneObject.h"

namespace eae6320 
{
	namespace Scene
	{
		struct sSceneData 
		{
			// TODO: I may need a copy constructor

			~sSceneData();

			// TODO: One idea for error handling is that if we run out of sceneIDs we could assume that SOME scenes have been unloaded, so we could search 
			// through our scenes to find the highest active ID and set our nextSceneID to that + 1
			static uint16_t nextSceneID;

			// This is an array of pointers because other objects derive from cSceneObject.
			cSceneObject** m_sceneObjects = nullptr;
			int m_numSceneObjects = 0;

			// This gives an implicit limit of about 60,000 scenes that can be loaded.
			// I could see that being a problem when games are left running in sleep mode rather than being shut down,
			// or for open world games with lots of level streaming.
			uint16_t m_sceneID = 0;

			void SetupData(int i_numSceneObjects, eae6320::Scene::cSceneObject** sceneObjects);
			void UnloadData();

		private: 
			void DeleteSceneObjects();
		};
	}
}
