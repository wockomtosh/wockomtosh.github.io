#pragma once

#include <cstdint>

#include <Engine/Results/Results.h>
#include <Engine/Physics/sRigidBodyState.h>
#include <unordered_map>

namespace eae6320
{
	namespace Scene
	{
		// It is required to create a static Load function for any class that inherits from cSceneObject.
		// This function should take the form of eae6320::cResult Load(eae6320::Scene::cSceneObject*& o_sceneObject, std::unordered_map<std::string, std::string> additionalData)
		// This function should allocate memory for the scene object and load the additional data. Scene object specific data will be loaded by the scene system.
		// If we want to store a reference to this object somewhere then we should do it here. For example, we could store the mesh in a list of meshes
		// Or if this is a character then we could call a function to tell the character manager that this is the character object
		// For persistent objects they probably need to check if they already exist in the world so they aren't reloaded
		class cSceneObject
		{
		public:
			cSceneObject();
			// This takes the place of an Unload function. Make sure you implement a destructor for your derived class
			virtual ~cSceneObject() = default;

			// TODO: The scene should have ownership of scene objects, but we need something to let other parts of the code know that scene objects have been unloaded so they aren't used elsewhere.

			// Not required, but does nothing normally
			virtual void OnSceneLoaded() {}


			inline uint32_t GetObjectID() const { return m_objectID; }

			inline uint16_t GetObjectType() const { return m_objectType; }
			inline void SetObjectType(uint16_t i_objectType) { m_objectType = i_objectType; }

			inline bool IsPersistentBetweenScenes() const { return m_persistentBetweenScenes; }
			inline void SetPersistentBetweenScenes(const bool i_persistentBetweenScenes) { m_persistentBetweenScenes = i_persistentBetweenScenes; }

		private:
			
			
		public:
			static uint32_t nextObjectID;

			Physics::sRigidBodyState m_rigidbody;

		private:
			// This gives an implicit limit of a little over 4 billion objects allowed to be loaded. 
			// This could be a problem since loading/unloading a scene would give all the scene objects new IDs. 
			// Ideally if I made an editor for scenes then it would build these IDs (or guids) into the files. 
			// However, I think this should work for now and it saves significant memory compared to a guid.
			// You could unload and reload a scene of 100,000 objects 40,000 times. For some games I'd think that's not enough, particularly 
			// because modern consoles make it really easy to never really turn off a game.
			uint32_t m_objectID; 
			uint16_t m_objectType;
			bool m_persistentBetweenScenes = false;
		};
	}
}