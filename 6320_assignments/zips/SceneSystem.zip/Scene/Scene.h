#pragma once

#include <Engine/Results/Results.h>

#include "cSceneObject.h"
#include "sSceneData.h"

#include <functional>
#include <string>

namespace eae6320
{
	namespace Scene
	{
		cResult Initialize(const uint16_t maxPersistentObjects = 32, const uint16_t maxLoadedScenes = 64);

		//This unloads all cSceneObjects
		cResult Cleanup();

		void RegisterObjectLoadFunction(const uint16_t i_objectType, 
			std::function<eae6320::cResult(eae6320::Scene::cSceneObject*& o_sceneObject, std::unordered_map<std::string, std::string> additionalData)> i_objectLoadFunction);

		// Unloads all non-persistent cSceneObjects and loads in a new scene. Returns the scene ID, which is 0 if it failed
		cResult LoadNewScene(const char* i_path, uint16_t& o_sceneID);
		// Loads in a new scene but does not unload any other scenes. Returns the scene ID, which is 0 if it failed
		cResult LoadAdditionalScene(const char* i_path, uint16_t& o_sceneID);
		// Unloads a particular scene (used when multiple scenes are loaded)
		cResult UnloadSceneByID(const uint16_t i_sceneID);


		// Finds a scene object given its ID. If a scene ID is also given that is used to find the object more efficiently (in cases where the object isn't in the first scene)
		// This isn't particularly efficient, even with a scene ID, so be careful using it frequently. 
		cResult GetSceneObjectByID(cSceneObject*& o_sceneObject, const uint32_t i_objectID, const uint16_t i_sceneID = 0);

		// Keep in mind that persistent objects are not stored in scene data
		cResult GetSceneDataByID(sSceneData& o_sceneData, const uint16_t i_sceneID);

		// TODO: Should I return a copy of the pointer to persistent scene objects? I don't want the user to try to free an old pointer and end up wrecking things.
		cResult GetPersistentSceneObjects(cSceneObject**& o_persistentSceneObjects, int& o_numPersistentSceneobjects);

		// This gets all scene objects of a given type throughout all scenes and persistent objects. If you give an optional scene ID it will only search that scene
		// This also has a max amount of scene objects it will give, passed in by the user. This is the amount of space allocated for o_sceneObjects.
		// Currently this function never fails, but I decided to still have it return a result so that it's easier to refactor later if necessary
		cResult GetSceneObjectsByType(cSceneObject**& o_sceneObjects, int& o_numSceneObjectsOfType, const uint16_t i_objectType, const int maxSceneObjectsReturned, const uint16_t i_sceneID = 0);
	}
}