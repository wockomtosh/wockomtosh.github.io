#include "cSceneObject.h"

uint32_t eae6320::Scene::cSceneObject::nextObjectID = 0;

eae6320::Scene::cSceneObject::cSceneObject() :
	m_objectType(0)
{
	m_objectID = nextObjectID;
	nextObjectID++;
}
