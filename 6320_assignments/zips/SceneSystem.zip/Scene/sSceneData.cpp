#include "sSceneData.h"

// I'm starting this at 1 so that I can reserve 0 as a blank ID
uint16_t eae6320::Scene::sSceneData::nextSceneID = 1;

eae6320::Scene::sSceneData::~sSceneData()
{
	UnloadData();
}

void eae6320::Scene::sSceneData::SetupData(int i_numSceneObjects, eae6320::Scene::cSceneObject** sceneObjects)
{
	// This shouldn't ever really happen, but to be safe we should check to free old memory before allocating more.
	if (m_sceneObjects)
	{
		DeleteSceneObjects();
	}
	m_numSceneObjects = i_numSceneObjects;
	m_sceneObjects = sceneObjects;
	m_sceneID = nextSceneID;
	nextSceneID++;
}

void eae6320::Scene::sSceneData::UnloadData()
{
	// Delete each individual pointer, then delete the array
	DeleteSceneObjects();
	m_numSceneObjects = 0;
	m_sceneID = 0;
}

void eae6320::Scene::sSceneData::DeleteSceneObjects()
{
	if (!m_sceneObjects) return;

	for (int i = 0; i < m_numSceneObjects; i++)
	{
		delete m_sceneObjects[i];
	}
	delete[] m_sceneObjects;
	m_sceneObjects = nullptr;
}
